# CargaFit v2

Versão conectada ao Supabase.

## Variáveis obrigatórias na Vercel
- VITE_SUPABASE_URL
- VITE_SUPABASE_ANON_KEY

Depois de adicionar as variáveis na Vercel, faça novo Deploy.
